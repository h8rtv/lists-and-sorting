#pragma once

const char* ARQUIVOS[7] = {
  "arquivocomprimidonomerg/NomeRG10.txt",
  "arquivocomprimidonomerg/NomeRG50.txt",
  "arquivocomprimidonomerg/NomeRG100.txt",
  "arquivocomprimidonomerg/NomeRG1K.txt",
  "arquivocomprimidonomerg/NomeRG10K.txt",
  "arquivocomprimidonomerg/NomeRG1M.txt",
  "arquivocomprimidonomerg/NomeRG100M.txt"
};

const char ARQUIVO_SAIDA_SEQUENCIAL[] = "output_file_sequencial.txt";
const char ARQUIVO_SAIDA_ENCADEADA[] = "output_file_encadeada.txt";