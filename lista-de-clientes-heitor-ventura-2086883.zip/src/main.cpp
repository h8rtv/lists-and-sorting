#include "Principal/Principal.h"

int main() {
  Principal principal;
}
