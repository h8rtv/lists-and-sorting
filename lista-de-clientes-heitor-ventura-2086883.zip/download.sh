rm -rf arquivocomprimidonomerg
rm -rf nomesergs.zip
wget -O nomesergs.zip http://dainf.ct.utfpr.edu.br/~maurofonseca/lib/exe/fetch.php?media=cursos:if63c:arquivocomprimidonomerg.zip
unzip nomesergs.zip -d arquivocomprimidonomerg
rm -rf nomesergs.zip
